from __future__ import unicode_literals
from django.db import models
from ..login_register.models import User, UserManager
from ..user_profile.models import Profile
