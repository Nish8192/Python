from __future__ import unicode_literals

from django.apps import AppConfig


class ValidateEmailConfig(AppConfig):
    name = 'Validate_Email'
