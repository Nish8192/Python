from __future__ import unicode_literals

from django.apps import AppConfig


class TravelDashboardConfig(AppConfig):
    name = 'Travel_Dashboard'
